class Car {
  #brand;
  #model;
  speed = 0;
  isTrunkOpen = false;
  constructor(brand, model) {
    this.#brand = brand;
    this.#model = model;
  }
  displayInfo() {
    console.log(`${this.#brand} ${this.#model}, Speed : ${this.speed} km/h ${this.isTrunkOpen ? 'The trunk is opened' : 'The trunk is closed'}`);
  }

  go() {
    if (this.speed <= 195 && this.speed >= 0) this.speed += 5;
    if(this.isTrunkOpen && this.speed>0)
            {
                this.closeTrunk();
                console.log("Trunk was open. It has been closed because the car started moving.");
    }
        
  }

  brake() {
    if (this.speed>=5) {
      this.speed -= 5;
    }
        else {
            this.speed=0;
        }
  }

  openTrunk() {
    if (this.speed === 0) 
      this.isTrunkOpen = true;
        else 
        {   this.closeTrunk();
            console.log('The car is moving');
        }
  }

  closeTrunk() {
    this.isTrunkOpen = false;
  }
}

const firstCar = new Car("Toyota", "Corolla");
const secondCar = new Car("Tesla", "Model 3");


class RaceCar extends Car {
    
    acceleration;
    constructor(brand, model, acceleration)
        {
            super(brand, model);
            this.acceleration= acceleration;
        }
    go() {

        this.speed +=this.acceleration ;
                if(this.speed >300)
                    this.speed=300;
                
    }
    
    openTrunk()
    {
        console.log('Race cars do not have a trunk');
    }

    closeTrunk()
    {
        console.log('Race cars do not have a trunk');
    }

    displayInfo()
    {
        console.log(`${this.brand} ${this.model}, Speed : ${this.speed} km/h`);
    }
}

const raceCar = new RaceCar('McLaren', 'F1', 20);

