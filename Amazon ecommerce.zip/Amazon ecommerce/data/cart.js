export let cart;

loadFromStorage();

export function loadFromStorage() {
  cart = JSON.parse(localStorage.getItem("cart"));
}
const timeOuts = {};
export function addedToCartMessage(productId) {
  const previousTimeOut = timeOuts[productId];
  if (previousTimeOut) clearTimeout(previousTimeOut);
  const addedToCart = document.querySelector(`.js-added-to-cart-${productId}`);
  addedToCart.classList.add("added-to-cart-active");
  const timeoutId = setTimeout(() => {
    addedToCart.classList.remove("added-to-cart-active");
  }, 2000);
  timeOuts[productId] = timeoutId;
}

export function saveToStorage() {
  localStorage.setItem("cart", JSON.stringify(cart));
}
export function addToCart(productId, quantity) {
  if (quantity === undefined) {
    const selector = document.querySelector(`.js-quantity-selector-${productId}`);
    quantity = selector ? Number(selector.value) : 1;
  }

  let matchingItem;
  cart.forEach((cartItem) => {
    if (productId === cartItem.productId) {
      matchingItem = cartItem;
    }
  });

  if (matchingItem) {
    matchingItem.quantity += quantity;
  } else {
    cart.push({
      productId,
      quantity,
      deliveryOptionId: "1",
    });
  }
  saveToStorage();
}



export function removeFromCart(productId) {
  const newCart = [];

  cart.forEach((cartItem) => {
    if (cartItem.productId !== productId) newCart.push(cartItem);
  });

  cart = newCart;
  saveToStorage();
}
export function updateDeliveryOption(productId, deliveryOptionId) {
  let matchingItem;
  cart.forEach((cartItem) => {
    if (productId === cartItem.productId) {
      matchingItem = cartItem;
    }
  });

  // Verificarea este DUPĂ bucla forEach
  if (matchingItem) {
    matchingItem.deliveryOptionId = deliveryOptionId;
    saveToStorage();
  }
  // Dacă nu există matchingItem, nu facem nimic
}

export function loadСart(fun) {
  const xhr = new XMLHttpRequest();
  xhr.addEventListener('load', () => {
    console.log(xhr.response);
});

  fun();
  ;
  xhr.open('GET', 'https://supersimplebackend.dev/cart');
  xhr.send();
}