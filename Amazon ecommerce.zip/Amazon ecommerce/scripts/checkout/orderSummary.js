import {cart} from '../../data/cart-class.js'
import { products } from "../../data/products.js";
import { formatCurrency } from "../utils/money.js";
import { hello } from "https://unpkg.com/supersimpledev@1.0.1/hello.esm.js";
import dayjs from "https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js";
import {
  deliveryOptions,
  getDeliveryOption,
} from "../../data/deliveryOptions.js";
import { getProduct } from "../../data/products.js";
import { renderPaymentSummary } from "./paymentSummary.js";
import { renderCheckoutHeader } from "./checkoutHeader.js";
import { calculateDeliveryDate } from "../../data/deliveryOptions.js";
export function renderOrderSummary() {
  let cartSummaryHTML = "";
  cart.cartItems.forEach((cartItem) => {
    const productId = cartItem.productId;
    const matchingProduct = getProduct(productId);
    const deliveryOptionId = cartItem.deliveryOptionId;
    const deliveryOption = getDeliveryOption(deliveryOptionId);
    calculateDeliveryDate(deliveryOption);
    cartSummaryHTML += `
                  <div class="cart-item-container js-cart-item-container-${
                    matchingProduct.id
                  } js-cart-item-container">
            <div class="delivery-date">
              Delivery date : ${calculateDeliveryDate(deliveryOption)}
            </div>

            <div class="cart-item-details-grid">
              <img class="product-image"
                src="${matchingProduct.image}">

              <div class="cart-item-details js-cart-item-details">
                <div class="product-name js-product-name-test-${
                  matchingProduct.id
                }">
                  ${matchingProduct.name}
                </div>
                <div class="product-price js-product-price-${
                  matchingProduct.id
                }">${matchingProduct.getPrice()}</div>
                <div class="product-quantity js-product-quantity js-product-quantity-test-${
                  matchingProduct.id
                }">
                  <span>
                    Quantity: <span class="quantity-label js-quantity-label">${
                      cartItem.quantity
                    }</span>
                  </span>
                  <span data-product-id = "${
                    matchingProduct.id
                  }" class="update-quantity-link link-primary js-update-quantity-link">
                    Update
                  </span>
                  <input class="quantity-input js-quantity-input">
                  <span data-product-id = "${
                    matchingProduct.id
                  }"  class="save-quantity-link link-primary js-save-quantity">Save</span>
                  <span data-product-id = "${
                    matchingProduct.id
                  }" class="delete-quantity-link link-primary js-delete-link js-delete-link-${
      matchingProduct.id
    }">
                    Delete
                  </span>
                </div>
              </div>

              <div class="delivery-options">
                <div class="delivery-options-title">
                  Choose a delivery option:
                </div>
                ${deliveryOptionsHTML(matchingProduct, cartItem)}
              </div>
            </div>
          </div>

    `;
  });

  function deliveryOptionsHTML(matchingProduct, cartItem) {
    let html = "";
    deliveryOptions.forEach((deliveryOption) => {
      const today = dayjs();
      let deliveryDate = today.add(deliveryOption.deliveryDays, "days");
      calculateDeliveryDate(deliveryOption);
      const priceString =
        deliveryOption.priceCents === 0
          ? "FREE"
          : `$${formatCurrency(deliveryOption.priceCents)}`;

      const isChecked = deliveryOption.id === cartItem.deliveryOptionId;
      html += `
                <div class="delivery-option js-delivery-option js-test-deliveryOption-${matchingProduct.id}-${deliveryOption.id}" data-product-id = "${matchingProduct.id}" data-delivery-option-id="${deliveryOption.id}">
                  <input type="radio" ${isChecked ? "checked" : ""}
                    class="delivery-option-input js-test-delivery-option-input-${matchingProduct.id}-${deliveryOption.id}"
                    name="delivery-option-${matchingProduct.id}">
                  <div>
                    <div class="delivery-option-date">
                      ${calculateDeliveryDate(deliveryOption)}
                    </div>
                    <div class="delivery-option-price">
                      ${priceString} - Shipping
                    </div>
                  </div>
                </div>
    `;
    });
    return html;
  }

  function updateQuantity(productId, newQuantity) {
    cart.cartItems.forEach((element) => {
      if (productId === element.productId) element.quantity = newQuantity;
    });
  }
  document.querySelector(".js-order-summary").innerHTML = cartSummaryHTML;

  document.querySelectorAll(`.js-delete-link`).forEach((link) => {
    link.addEventListener("click", () => {
      const productId = link.dataset.productId;
      cart.removeFromCart(productId);
      renderOrderSummary();
      renderPaymentSummary();
      renderCheckoutHeader(cart);
    });
  });
  document.querySelectorAll(".js-update-quantity-link").forEach((link) => {
    link.addEventListener("click", () => {
      const { productId } = link.dataset;
      const cartItemContainer = document.querySelector(
        `.js-cart-item-container-${productId}`
      );
      cartItemContainer.classList.add("is-editing-quantity");
      renderPaymentSummary();
    });
  });

  document.querySelectorAll(".js-save-quantity").forEach((link) => {
    link.addEventListener("click", () => {
      const { productId } = link.dataset;
      const cartItemContainer = document.querySelector(
        `.js-cart-item-container-${productId}`
      );
      if (cartItemContainer.classList.contains("is-editing-quantity")) {
        const input = cartItemContainer.querySelector(".js-quantity-input");
        cartItemContainer.classList.remove("is-editing-quantity");
        updateQuantity(productId, Number(input.value));
        const quantitySpan =
          cartItemContainer.querySelector(".js-quantity-label");
        quantitySpan.innerHTML = input.value;
        if (input.value >= 0 && input.value < 1000) {
          renderPaymentSummary();
          renderCheckoutHeader();
        }
      }
    });
  });
  document.querySelectorAll(".js-save-quantity").forEach((link) => {
    document.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        const { productId } = link.dataset;
        const cartItemContainer = document.querySelector(
          `.js-cart-item-container-${productId}`
        );
        if (cartItemContainer.classList.contains("is-editing-quantity")) {
          const input = cartItemContainer.querySelector(".js-quantity-input");
          cartItemContainer.classList.remove("is-editing-quantity");
          updateQuantity(productId, Number(input.value));
          renderPaymentSummary();
          renderCheckoutHeader();
          const quantitySpan =
            cartItemContainer.querySelector(".js-quantity-label");
          quantitySpan.innerHTML = input.value;
          if (input.value >= 0 && input.value < 1000) {
            renderOrderSummary();
            renderPaymentSummary();
            renderCheckoutHeader();
          }
        }
      }
    });
  });

  document.querySelectorAll(".js-delivery-option").forEach((element) => {
    element.addEventListener("click", () => {
      const { productId, deliveryOptionId } = element.dataset;
      cart.updateDeliveryOption(productId, deliveryOptionId);
      renderOrderSummary();
      renderPaymentSummary();
    });
  });
}
