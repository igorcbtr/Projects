import { orders } from "../data/orders.js";
import { loadProductsFetch, getProduct } from "../data/products.js";
import dayjs from "https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js";
import { formatCurrency } from "../scripts/utils/money.js";
import { cart } from "../data/cart-class.js";
console.log(orders);
function calculateCartQuantity() {
        let cartQuantity = 0;
        cart.cartItems.forEach((cartItem) => {
          cartQuantity += cartItem.quantity;
        });
        document.querySelector(".js-cart-quantity").innerHTML = `${cartQuantity === 0 ? '' : cartQuantity}`;
    }
async function loadPage() {
     
    calculateCartQuantity();
    
  let ordersHTML = "";
  await loadProductsFetch();
  orders.forEach((order) => {
    ordersHTML += `
    <div class="order-container">    
          <div class="order-header">
            <div class="order-header-left-section">
              <div class="order-date">
                <div class="order-header-label">Order Placed:</div>
                <div>${dayjs(order.orderTime).format("D MMMM")}</div>
              </div>
              <div class="order-total">
                <div class="order-header-label">Total:</div>
                <div>$${formatCurrency(order.totalCostCents)}</div>
              </div>
            </div>

            <div class="order-header-right-section">
              <div class="order-header-label">Order ID:</div>
              <div>${order.id}</div>
            </div>
          </div>
         <div class="order-details-grid js-order-details-grid">
            ${productsList(order)}
          </div>
        </div>
    </div>
`;

  });
  document.querySelector(".js-orders-grid").innerHTML = ordersHTML;
 document.querySelectorAll('.js-buy-again').forEach((button) => {
  button.addEventListener('click', () => {
    const productId = button.dataset.productId;
    const productQuantity = Number(button.dataset.productQuantity) || 1; // fallback 1
    cart.addToCart(productId, productQuantity);
    calculateCartQuantity();
    console.log(cart);
    // Mesajul „Added”
    button.innerHTML = 'Added';
    setTimeout(() => {
      button.innerHTML = `
        <img class="buy-again-icon" src="images/icons/buy-again.png">
        <span class="buy-again-message">Buy it again</span>
      `;
    }, 1000);
  });
});

  
}
    function productsList(order) {
            let productListHTML = "";
      order.products.forEach((productDetails) => {
        const product = getProduct(productDetails.productId);
        console.log(product);
        productListHTML += `
             <div class="product-image-container">
              <img src="${product.image}">
            </div>

            <div class="product-details">
              <div class="product-name">
                ${product.name}
              </div>
              <div class="product-delivery-date">
                Arriving on: ${dayjs(productDetails.estimatedDeliveryTime).format('D MMMM')}
              </div>
              <div class="product-quantity">
                Quantity: ${productDetails.quantity}
              </div>
              <button class="buy-again-button button-primary js-buy-again" data-product-quantity = ${productDetails.quantity} data-product-id = ${product.id}>
                <img class="buy-again-icon" src="images/icons/buy-again.png">
                <span class="buy-again-message">Buy it again</span>
              </button>
            </div>

            <div class="product-actions">
              <a href="tracking.html?orderId=${order.id}&productId=${product.id}">
                <button class="track-package-button button-secondary">
                  Track package
                </button>
              </a>
            </div>`;
      });
      return productListHTML;
    }
if (window.location.pathname.includes('orders.html')) {
  loadPage();
}

export function getOrder(orderId)
    {
        let matchingOrder;
        orders.forEach((order) => {
            if(order.id===orderId)  
                {matchingOrder=order};
        });
        return matchingOrder;
    }
