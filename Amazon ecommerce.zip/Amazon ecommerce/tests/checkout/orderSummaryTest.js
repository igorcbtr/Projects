import { cart } from '../../data/cart-class.js';
import { renderOrderSummary } from '../../path/to/renderOrderSummary.js'; 
import { renderPaymentSummary } from '../../path/to/paymentSummary.js';
import { renderCheckoutHeader } from '../../path/to/checkoutHeader.js';

// mock funcții importate pe care le apelezi în renderOrderSummary, ca să nu dea eroare
spyOn(window, 'renderPaymentSummary').and.callFake(() => {});
spyOn(window, 'renderCheckoutHeader').and.callFake(() => {});

describe('renderOrderSummary', () => {

  beforeEach(() => {
    // Pune containerul în DOM
    document.body.innerHTML = `
      <div class="js-order-summary"></div>
    `;

    // Reset cart la starea inițială cu 2 produse
    cart.cartItems = [
      {
        productId: "e43638ce-6aa0-4b85-b27f-e1d07eb678c6",
        quantity: 2,
        deliveryOptionId: "1",
      },
      {
        productId: "15b6fc6f-327a-4ec4-896f-486349e85a3d",
        quantity: 1,
        deliveryOptionId: "2",
      },
    ];
  });

  it('displays the cart items', () => {
    renderOrderSummary();

    const cartItems = document.querySelectorAll('.js-cart-item-container');
    expect(cartItems.length).toBe(2);

    const firstProductName = document.querySelector('.js-product-name-test-e43638ce-6aa0-4b85-b27f-e1d07eb678c6');
    expect(firstProductName).not.toBeNull();
    expect(firstProductName.textContent).toContain(''); // poți pune numele așteptat aici

    const quantityLabels = document.querySelectorAll('.js-quantity-label');
    expect(quantityLabels[0].textContent).toBe('2');
    expect(quantityLabels[1].textContent).toBe('1');
  });

  it('removes a product when delete link is clicked', () => {
    renderOrderSummary();

    const deleteButton = document.querySelector('.js-delete-link-e43638ce-6aa0-4b85-b27f-e1d07eb678c6');
    expect(deleteButton).not.toBeNull();

    deleteButton.click();

    // După click se face rerender, deci reapelăm renderOrderSummary dacă nu este apelat automat
    // (dar în funcția ta se apelează automat, deci e OK)

    const cartItems = document.querySelectorAll('.js-cart-item-container');
    expect(cartItems.length).toBe(1);
  });

  it('updates delivery option when delivery option clicked', () => {
    renderOrderSummary();

    const deliveryOption = document.querySelector('.js-test-deliveryOption-15b6fc6f-327a-4ec4-896f-486349e85a3d-1'); // un delivery option pentru produsul 2
    expect(deliveryOption).not.toBeNull();

    deliveryOption.click();

    // Verifică că deliveryOptionId s-a schimbat în cart
    const cartItem = cart.cartItems.find(c => c.productId === "15b6fc6f-327a-4ec4-896f-486349e85a3d");
    expect(cartItem.deliveryOptionId).toBe("1"); // s-a schimbat de la "2" la "1"

    // Și DOM-ul se va re-renderiza, deci poți verifica încă o dată dacă s-a aplicat corect
  });

});
