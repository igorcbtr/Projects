 let calculation = localStorage.getItem('calculation') || '';
      showParagraphStorage(calculation);
      if(calculation==='')
    {
      document.querySelector('.calculation-text')
        .innerText = '\n';
    }
      function updateCalculation(value) {
        calculation += value;
        showParagraphvalue(calculation);
        localStorage.setItem('calculation', calculation);
      }

      // Optional: you can also create a function in order
      // to reuse this code.
      function saveCalculation() {
        localStorage.setItem('calculation', calculation);
      }

      function showParagraphvalue(calculation)
      {
        document.querySelector('.calculation-text')
          .innerText = `${calculation}`;
      }
      function showParagraphCalculation(calculation)
      {
        document.querySelector('.calculation-text')
          .innerText = `${calculation}`;
      }
      function showParagraphStorage(value)
      {
        document.querySelector('.calculation-text')
          .innerText = `${value}`;

      }
      function cleanParagraph()
      {
        document.querySelector('.calculation-text')
          .innerText = '\n';
      }